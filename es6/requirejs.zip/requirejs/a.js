var requires=require("./requires")

requires.defines(()=>{
    var name=123
    return name
})